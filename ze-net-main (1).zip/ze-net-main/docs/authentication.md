# Authentication

Discord OAuth via Supabase Auth. There is one client setting that must not be changed
without reading this page.

## The flow

1. `/login` calls `supabase.auth.signInWithOAuth({ provider: 'discord', redirectTo: origin + '/account' })`.
   In PKCE mode this generates a code verifier, stores it in `localStorage`, and sends its
   hash to Supabase as a `code_challenge`.
2. Discord authorises, Supabase redirects to `/account?code=...`.
3. On page load the supabase client's `detectSessionInUrl` sees the `?code=`, finds the
   matching verifier in storage, exchanges them for a session, and strips the param.
4. `onAuthStateChange` fires, `useAuth` publishes the user, `/account` renders.

## `flowType: 'pkce'` is load-bearing

`src/services/supabase.js` pins it explicitly. supabase-js defaults to `'implicit'`, and that
default silently breaks Discord sign-in here:

- In implicit mode `signInWithOAuth` never stores a code verifier.
- On the callback, the client's `_isPKCECallback()` requires **both** a `?code=` param **and**
  a stored verifier. With no verifier it returns false.
- With no `#access_token` either, the client concludes the URL isn't an auth callback at all,
  ignores the code, and reports the user as signed out — with no error anywhere.
- `/account` then hits `if (!user) navigate('/login')` and the user is back at the form,
  looking like sign-in "just didn't work."

If sign-in ever starts bouncing to `/login` again, check this setting first.

## Do not add a manual `exchangeCodeForSession`

`App.jsx` used to render an `<AuthHandler />` that pulled `?code=` off the URL and exchanged
it by hand. With `detectSessionInUrl` on (the default), the client is already doing that
exchange during initialisation. Two exchanges race, the auth code is single-use, and the
verifier is deleted after the first attempt — so whichever call loses fails and the session
may never land. It's been removed. Don't reintroduce it.

## `useAuth` is a single shared store

`src/hooks/useAuth.js` holds one module-level subscription and one snapshot. Every component
calling `useAuth()` reads the same value.

It previously created a fresh subscription and a fresh `loading: true` per caller, so a page
mounting *after* auth resolved briefly saw `user: null` — long enough for guards like
`if (!user) navigate('/login')` to fire. There was also a 2-second timeout fallback that
called `getSession()` and hard-set the user to null; on a slow code exchange it fired mid-flight
and signed people out. The backstop now calls `getSession()` directly, which resolves only
after the client finishes processing the callback, so it can't report "signed out" early.

**When guarding a route, always check `loading` before acting on `user`:**

```jsx
const { user, loading } = useAuth();
useEffect(() => {
  if (loading) return;            // <- not optional
  if (!user) navigate('/login');
}, [user, loading, navigate]);
```

## Sessions

Stored in `localStorage` under `sb-<project-ref>-auth-token`, refreshed automatically.
Sign-out in `Layout.jsx` calls `signOut()` and then clears any leftover `sb-` keys.
