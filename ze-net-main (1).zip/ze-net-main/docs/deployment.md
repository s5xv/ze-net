# Deployment

Frontend and API deploy together to **Vercel** from the GitHub repo. The database and auth
are **Supabase**. The Discord bot is separate and does not deploy to Vercel.

## Vercel

`vercel.json` already handles this — no dashboard build config needed:

- Build `npm run build` → output `dist/`
- `/api/*` routes to the serverless functions in `api/`
- `/site/:slug/embed` rewrites to `api/embed`
- Everything else rewrites to `index.html` (SPA fallback, so deep links like
  `/admin` don't 404 on refresh)
- `sw.js` and HTML are sent `no-store`; hashed assets under `/assets/` are cached forever

Set every variable from `.env.example` under **Settings → Environment Variables** for
Production and Preview. `VITE_*` values are baked in at build time, so **changing one
requires a redeploy** — restarting won't pick it up.

## Supabase

**Auth → Providers → Discord:** enable it, paste in the Discord app's client ID and secret.
Copy the callback URL Supabase shows you into the Discord Developer Portal under
OAuth2 → Redirects.

**Auth → URL Configuration:**

- *Site URL* — your production origin, e.g. `https://ze-net.vercel.app`
- *Redirect URLs* — must include `https://<your-domain>/account`, which is what
  `signInWithOAuth` passes as `redirectTo`. Add `http://localhost:5173/**` for dev.

If `/account` isn't on the allowlist Supabase silently falls back to the Site URL. Sign-in
still works, but users land somewhere unexpected.

**Database:** apply everything in `db/migrations/` in filename order. See
[`db/README.md`](../db/README.md).

## Keys — which goes where

| Key | Where it belongs | Notes |
|---|---|---|
| Supabase anon key | `VITE_SUPABASE_ANON_KEY` | Public by design. Safe in the bundle *because* RLS constrains it |
| Supabase service-role key | `SUPABASE_SERVICE_ROLE_KEY` | Bypasses RLS completely. `api/` only. Never behind a `VITE_` name |
| Discord webhooks | `DISCORD_ALERT_WEBHOOK`, `DISCORD_CHANGELOG_WEBHOOK` | Credentials — anyone with the URL can post to the channel |

These last two were hardcoded in `api/app.js` and `api/changelog.js`. They're now read from
the environment. **The old URLs are in this repo's git history, so rotate them:** delete the
webhooks in Discord (Server Settings → Integrations → Webhooks), create new ones, and put
the new URLs in Vercel.

There was also a `VITE_SUPABASE_SERVICE_ROLE_KEY` fallback in `src/services/supabase.js`. If
that variable was ever set in Vercel, the service-role key was shipped in the public bundle
and should be treated as compromised — rotate it in Supabase → Settings → API, and delete the
`VITE_SUPABASE_SERVICE_ROLE_KEY` variable.

## Discord bot

Deployed on its own (Docker, per `discord-bot/docker-compose.yml`) with its own `.env`.
Nothing in `discord-bot/` is built or run by Vercel.

## Self-hosting the SPA

`deploy/Dockerfile` + `deploy/nginx.conf` build a static nginx image. Unused while on Vercel,
kept for portability. Build from the repo root:

```bash
docker build -f deploy/Dockerfile -t ze-net .
```

Note this serves the SPA only — there's no `/api` in that image, since those are Vercel
functions.
