# Scratch notes: admin dashboard additions

> **Stale.** These are hand-written snippets from an earlier session, kept only for
> reference. Parts are already implemented in `src/pages/Admin.jsx` (the
> `businessRegistrations` state and the business approve/reject handlers, for example).
> Check the current source before copying anything out of here.
>
> Note also that several snippets below write to `sites` and other tables directly from
> the browser client. That path is subject to RLS and can fail silently — see
> [`../admin-dashboard.md`](../admin-dashboard.md). New privileged actions should go
> through `/api/app?action=admin-*` instead.

```js
Add these state variables after the existing ones:
  const [businessRegistrations, setBusinessRegistrations] = useState([]);
  const [adSubmissions, setAdSubmissions] = useState([]);

Add these to fetchData():
    const { data: businessData } = await supabase.from('business_registrations').select('*').order('created_at', { ascending: false });
    setBusinessRegistrations(businessData || []);
    const { data: adSubData } = await supabase.from('ad_submissions').select('*').order('created_at', { ascending: false });
    setAdSubmissions(adSubData || []);

Add these handler functions:
  const handleApproveBusiness = async (id) => {
    if (confirm('Approve this business registration?')) {
      await supabase.from('business_registrations').update({ status: 'approved' }).eq('id', id);
      fetchData();
    }
  };

  const handleRejectBusiness = async (id) => {
    if (confirm('Reject this business registration?')) {
      await supabase.from('business_registrations').delete().eq('id', id);
      fetchData();
    }
  };

  const handleApproveAd = async (submission) => {
    if (!confirm(`Approve this ad? This will deduct $${submission.tier === 'gold' ? 2500 : submission.tier === 'silver' ? 1200 : 500} from their balance.`)) return;
    
    const price = submission.tier === 'gold' ? 2500 : submission.tier === 'silver' ? 1200 : 500;
    
    // Check balance
    const { data: balData } = await supabase.from('site_balances').select('balance').eq('user_id', submission.user_id).single();
    if (!balData || balData.balance < price) {
      alert('User has insufficient balance');
      return;
    }
    
    // Deduct balance
    await supabase.from('site_balances').update({ balance: balData.balance - price }).eq('user_id', submission.user_id);
    
    // Create the ad
    await supabase.from('ads').insert({
      title: submission.company_name,
      description: `Sponsored by ${submission.company_name}`,
      link_url: submission.redirect_url,
      image_url: submission.banner_image,
      tier: submission.tier,
      is_active: true
    });
    
    // Delete submission
    await supabase.from('ad_submissions').delete().eq('id', submission.id);
    
    fetchData();
  };

  const handleRejectAd = async (id) => {
    if (confirm('Reject this ad submission?')) {
      await supabase.from('ad_submissions').delete().eq('id', id);
      fetchData();
    }
  };

Add 'business' and 'ad-submissions' to the tabs array.

Add these UI sections before the closing </div> of the admin page:

        {activeTab === 'business' && (
          <div className="bg-white dark:bg-[#303134] rounded-xl border border-gray-200 dark:border-gray-700 p-6 shadow-sm">
            <h2 className="text-xl font-bold mb-6">Business Registrations ({businessRegistrations.filter(b => b.status === 'pending').length} pending)</h2>
            {businessRegistrations.length === 0 ? <p className="text-gray-500 text-center py-12">No registrations</p> : (
              <div className="space-y-3">
                {businessRegistrations.map((reg) => (
                  <div key={reg.id} className={`p-4 border rounded-lg ${reg.status === 'pending' ? 'bg-blue-500/5 border-blue-500/20' : 'bg-gray-50 dark:bg-[#202124]'}`}>
                    <div className="flex justify-between items-start">
                      <div className="flex-grow">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-semibold">{reg.business_name}</h3>
                          {reg.status === 'pending' && <span className="px-2 py-0.5 text-xs font-bold text-blue-600 bg-blue-500/10 border border-blue-500/20 rounded">PENDING</span>}
                        </div>
                        <p className="text-xs text-gray-500 mb-2">Owner: {reg.owner_discord} • Category: {reg.category}</p>
                        {reg.plot_coordinates && <p className="text-sm text-gray-700 dark:text-gray-300">Coords: {reg.plot_coordinates}</p>}
                        {reg.discord_invite && <p className="text-sm text-gray-700 dark:text-gray-300">Discord: {reg.discord_invite}</p>}
                        {reg.website_url && <p className="text-sm text-gray-700 dark:text-gray-300">Website: {reg.website_url}</p>}
                      </div>
                      {reg.status === 'pending' && (
                        <div className="flex gap-2">
                          <button onClick={() => handleApproveBusiness(reg.id)} className="px-3 py-1.5 text-xs bg-green-600 hover:bg-green-700 text-white rounded-lg">Approve</button>
                          <button onClick={() => handleRejectBusiness(reg.id)} className="px-3 py-1.5 text-xs bg-red-600 hover:bg-red-700 text-white rounded-lg">Reject</button>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'ad-submissions' && (
          <div className="bg-white dark:bg-[#303134] rounded-xl border border-gray-200 dark:border-gray-700 p-6 shadow-sm">
            <h2 className="text-xl font-bold mb-6">Ad Submissions ({adSubmissions.filter(a => a.status === 'pending').length} pending)</h2>
            {adSubmissions.length === 0 ? <p className="text-gray-500 text-center py-12">No submissions</p> : (
              <div className="space-y-3">
                {adSubmissions.map((sub) => (
                  <div key={sub.id} className={`p-4 border rounded-lg ${sub.status === 'pending' ? 'bg-green-500/5 border-green-500/20' : 'bg-gray-50 dark:bg-[#202124]'}`}>
                    <div className="flex justify-between items-start">
                      <div className="flex-grow">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-semibold">{sub.company_name}</h3>
                          {sub.status === 'pending' && <span className="px-2 py-0.5 text-xs font-bold text-green-600 bg-green-500/10 border border-green-500/20 rounded">PENDING</span>}
                        </div>
                        <p className="text-xs text-gray-500 mb-2">Contact: {sub.contact_discord} • Tier: {sub.tier.toUpperCase()}</p>
                        <p className="text-sm text-gray-700 dark:text-gray-300">URL: {sub.redirect_url}</p>
                        {sub.banner_image && <img src={sub.banner_image} alt="Ad banner" className="mt-2 h-20 object-cover rounded" />}
                      </div>
                      {sub.status === 'pending' && (
                        <div className="flex gap-2">
                          <button onClick={() => handleApproveAd(sub)} className="px-3 py-1.5 text-xs bg-green-600 hover:bg-green-700 text-white rounded-lg">Approve & Charge</button>
                          <button onClick={() => handleRejectAd(sub.id)} className="px-3 py-1.5 text-xs bg-red-600 hover:bg-red-700 text-white rounded-lg">Reject</button>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
```
