# Admin dashboard

`/admin`, rendered by `src/pages/Admin.jsx`.

## Access

Three ways in, checked in this order:

1. `localStorage.admin_pw` matches `VITE_ADMIN_PASSWORD` — convenience only. It ships in the
   public bundle, so treat it as a speed bump, not a control.
2. `profiles.is_staff = true`, or a non-empty `profiles.staff_permissions` array. This is the
   real one.
3. If **no** staff user exists at all, the first authenticated visitor is let in so the
   instance can be bootstrapped. Promote someone to staff promptly — this stays open until
   one exists.

Client-side checks are UX. Every privileged action goes through `/api/app?action=admin-*`,
which re-checks `is_staff` server-side via `requireAdmin()`. That's the enforcement point.

## Privileged writes must go through /api

`public.sites` has RLS enabled with SELECT, INSERT, and UPDATE policies — and, originally, no
DELETE policy. PostgREST doesn't treat that as an error: a delete with no matching policy
removes zero rows and returns `{ error: null }`. Completely silent.

The Businesses tab used to call `supabase.from('sites').delete()` straight from the browser
and did exactly nothing, forever. It now calls `deleteSite()` like the Sites tab, which goes
through `/api/app?action=admin-delete-site` using the service-role key.

**Rule: if it's a staff-only mutation, it goes through `/api`.** The frontend's anon key is
constrained by RLS, and RLS failures are usually invisible.

## Deleting a site

`admin-delete-site` in `api/app.js`:

1. Resolves the site to get its `id` and `slug`; 404s if it's gone.
2. Clears child rows — by `site_id` across `SITE_CHILD_TABLES_BY_ID`, by `site_slug` across
   `SITE_CHILD_TABLES_BY_SLUG`. Best-effort: a table that doesn't exist is skipped.
3. Deletes the site. A `23503` (foreign key violation) comes back as a 409 naming the
   constraint, so the blocking table can be added to the lists above.
4. Re-queries to confirm the row is actually gone, rather than trusting a no-op.
5. Writes to `admin_audit_logs` and fires a Discord alert.

If you add a table with a `site_id` or `site_slug` column, add it to those lists **and** give
its foreign key `ON DELETE CASCADE`. Applying `db/migrations/20260803-fix-site-delete-cascade.sql`
handles the cascade for everything currently in the database.

## The message banner

It renders near the top of the page, above the tab strip. Errors from a button forty rows down
used to be invisible, which made failures read as "nothing happened." `showResult(text, type)`
now colours it by type and scrolls it into view on error. Use it instead of bare `setMessage`
for anything that can fail.
