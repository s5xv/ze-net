# Z&E Net

Centralized directory for the DemocracyCraft Minecraft server — site listings, reviews,
forums, marketplace, news, treasury/economy integration, and a staff admin dashboard.

**Stack:** React 19 + Vite (SPA) · Supabase (Postgres, Auth, Storage) · Vercel serverless
functions under `/api` · a separate Discord bot in `discord-bot/`.

---

## Layout

| Path | What's in it |
|---|---|
| `src/` | React app — `pages/` are routes, `components/` shared UI, `hooks/`, `services/` |
| `api/` | Vercel serverless functions. These hold the **service-role** Supabase key |
| `db/` | `schema.sql` plus `migrations/` — see [`db/README.md`](db/README.md) |
| `docs/` | Deployment, auth, and admin notes — start with [`docs/deployment.md`](docs/deployment.md) |
| `discord-bot/` | Standalone bot, deployed separately (not on Vercel) |
| `scripts/` | One-off developer utilities |
| `deploy/` | Docker + nginx for self-hosting the SPA. **Unused on Vercel** |
| `public/` | Static assets served as-is |

## Running locally

```bash
npm install
cp .env.example .env.local     # then fill in the values
npm run dev                    # http://localhost:5173
```

`/api/*` is proxied to `http://localhost:3001` in dev (see `vite.config.js`), so run
`vercel dev` alongside it if you need the serverless functions.

```bash
npm run build     # production build to dist/
npm run lint      # oxlint
```

## Environment variables

See [`.env.example`](.env.example) for the full list. Two rules that matter:

- Anything prefixed `VITE_` is **compiled into the public JS bundle**. Every visitor can
  read it. Never put a service-role key or a real secret behind a `VITE_` name.
- The service-role key goes in `SUPABASE_SERVICE_ROLE_KEY` (no prefix) and is only ever
  read by `api/`.

## Docs

- [`docs/deployment.md`](docs/deployment.md) — Vercel + Supabase setup, env vars, redirect URLs
- [`docs/authentication.md`](docs/authentication.md) — how Discord sign-in works, and the one setting that must not change
- [`docs/admin-dashboard.md`](docs/admin-dashboard.md) — staff access, site deletion, RLS notes
- [`db/README.md`](db/README.md) — applying schema and migrations

## Before you commit

- No credentials in source. Discord webhook URLs, tokens, and keys go in the environment.
- Schema changes go in `db/migrations/` as a new dated file — don't edit `db/schema.sql`
  in place, and don't leave the change only in the Supabase dashboard.
- `npm run build` should pass.
