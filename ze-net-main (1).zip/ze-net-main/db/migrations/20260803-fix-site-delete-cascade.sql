-- Fix: "can't delete sites from admin dashboard"
-- Run once in the Supabase SQL editor.
--
-- Two separate problems were blocking deletes:
--
--   1. Tables added after full-schema.sql (site_events, site_coupons,
--      staff_notes, claim_disputes, ...) reference public.sites without
--      ON DELETE CASCADE, so DELETE FROM sites raised a 23503 foreign key
--      violation.
--   2. public.sites has RLS enabled but NO delete policy, so any delete
--      issued from the browser (anon key) removed zero rows and returned no
--      error at all — a completely silent no-op.
--
-- The app code now routes every site delete through /api/app (service role,
-- which bypasses RLS) and clears child rows first, so this migration is a
-- belt-and-braces fix. It is safe to run more than once.

-- 1. Rewrite every FK pointing at public.sites to cascade on delete.
DO $$
DECLARE
  r record;
BEGIN
  FOR r IN
    SELECT con.oid,
           con.conname,
           rel.relname            AS child_table,
           nsp.nspname            AS child_schema,
           pg_get_constraintdef(con.oid) AS def
    FROM pg_constraint con
    JOIN pg_class rel  ON rel.oid = con.conrelid
    JOIN pg_namespace nsp ON nsp.oid = rel.relnamespace
    WHERE con.contype = 'f'
      AND con.confrelid = 'public.sites'::regclass
      AND con.confdeltype <> 'c'   -- 'c' = already ON DELETE CASCADE
  LOOP
    RAISE NOTICE 'Cascading %.% constraint %',
      r.child_schema, r.child_table, r.conname;
    EXECUTE format('ALTER TABLE %I.%I DROP CONSTRAINT %I',
                   r.child_schema, r.child_table, r.conname);
    EXECUTE format('ALTER TABLE %I.%I ADD CONSTRAINT %I %s ON DELETE CASCADE',
                   r.child_schema, r.child_table, r.conname,
                   regexp_replace(r.def, '\s+ON DELETE [A-Z ]+', '', 'g'));
  END LOOP;
END $$;

-- 2. discord_watches links by slug with no FK at all, so orphan rows linger.
DELETE FROM public.discord_watches w
WHERE NOT EXISTS (SELECT 1 FROM public.sites s WHERE s.slug = w.site_slug);

-- 3. Let staff delete sites directly, so a browser-side delete fails loudly
--    (permission error) instead of silently doing nothing.
DROP POLICY IF EXISTS "Staff can delete any site" ON public.sites;
CREATE POLICY "Staff can delete any site" ON public.sites
  FOR DELETE TO authenticated
  USING ((SELECT is_staff FROM public.profiles WHERE id = auth.uid()) = true);

-- 4. Verify: this should return zero rows once the migration has run.
SELECT con.conname, rel.relname AS child_table
FROM pg_constraint con
JOIN pg_class rel ON rel.oid = con.conrelid
WHERE con.contype = 'f'
  AND con.confrelid = 'public.sites'::regclass
  AND con.confdeltype <> 'c';
