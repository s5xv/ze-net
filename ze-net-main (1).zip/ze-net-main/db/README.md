# Database

Supabase Postgres. Two things live here:

- **`schema.sql`** — the full current schema: tables, indexes, RLS policies, functions.
  A reference snapshot, not an incremental script. Running it on an existing database
  will error on objects that already exist.
- **`migrations/`** — dated, incremental changes. These are what you actually run.

## Applying a migration

Supabase Dashboard → SQL Editor → paste the file → Run. Migrations here are written to be
safe to run more than once (`IF NOT EXISTS`, `DROP POLICY IF EXISTS`, and so on).

Run them in filename order:

| File | What it does |
|---|---|
| `20260803-fix-site-delete-cascade.sql` | Makes every FK pointing at `sites` cascade on delete, clears orphaned `discord_watches`, and adds a staff DELETE policy on `sites`. **Required** — without it, deleting a site from the admin dashboard fails |

## Adding a migration

Name it `YYYYMMDD-short-description.sql`, make it idempotent, and end it with a query that
verifies the change. Then fold the change into `schema.sql` so the snapshot stays accurate.

## Schema drift — worth knowing

`schema.sql` is behind the live database. Tables referenced by the app but missing from the
snapshot: `claim_disputes`, `review_media`, `site_coupons`, `site_events`, `staff_notes`,
`admin_audit_logs`, `changelog`, `threads`.

This is what broke site deletion. Those tables were added through the dashboard with plain
`REFERENCES public.sites(id)` and no `ON DELETE CASCADE`, so `DELETE FROM sites` failed on a
foreign-key violation. The migration above fixes the existing ones generically — it walks
`pg_constraint` rather than naming tables — but the real fix is to stop adding tables
outside of `migrations/`.

## RLS

Row Level Security is on for most tables. Two consequences that bite:

- The browser uses the **anon key** and is fully subject to RLS. A `DELETE` with no matching
  policy removes zero rows and **returns no error at all** — a silent no-op. If a write from
  the frontend "does nothing," check for a missing policy first.
- `/api` uses the **service-role key** and bypasses RLS entirely. Anything privileged must go
  through `/api` and must check `profiles.is_staff` itself, because the database won't.
