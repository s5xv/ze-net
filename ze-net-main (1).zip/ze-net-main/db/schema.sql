-- ============================================================
-- Z&E Net — Full Database Schema
-- Run this ENTIRE file in Supabase Dashboard → SQL Editor
-- ============================================================

SET search_path TO public;

-- Drop everything for a clean slate
DROP TABLE IF EXISTS public.listings CASCADE;
DROP TABLE IF EXISTS public.forum_cache CASCADE;
DROP TABLE IF EXISTS public.treasury_tokens CASCADE;
DROP TABLE IF EXISTS public.auto_deposit_rules CASCADE;
DROP TABLE IF EXISTS public.staff_payroll CASCADE;
DROP TABLE IF EXISTS public.staff_logs CASCADE;
DROP TABLE IF EXISTS public.business_registrations CASCADE;
DROP TABLE IF EXISTS public.challenge_progress CASCADE;
DROP TABLE IF EXISTS public.daily_challenges CASCADE;
DROP TABLE IF EXISTS public.user_achievements CASCADE;
DROP TABLE IF EXISTS public.search_analytics CASCADE;
DROP TABLE IF EXISTS public.search_history CASCADE;
DROP TABLE IF EXISTS public.collections CASCADE;
DROP TABLE IF EXISTS public.departments CASCADE;
DROP TABLE IF EXISTS public.wiki_comments CASCADE;
DROP TABLE IF EXISTS public.wiki_pages CASCADE;
DROP TABLE IF EXISTS public.site_verification_requests CASCADE;
DROP TABLE IF EXISTS public.ads CASCADE;
DROP TABLE IF EXISTS public.ad_requests CASCADE;
DROP TABLE IF EXISTS public.site_announcements CASCADE;
DROP TABLE IF EXISTS public.site_reports CASCADE;
DROP TABLE IF EXISTS public.withdrawal_requests CASCADE;
DROP TABLE IF EXISTS public.transactions CASCADE;
DROP TABLE IF EXISTS public.bookmarks CASCADE;
DROP TABLE IF EXISTS public.site_followers CASCADE;
DROP TABLE IF EXISTS public.site_comments CASCADE;
DROP TABLE IF EXISTS public.site_reviews CASCADE;
DROP TABLE IF EXISTS public.review_votes CASCADE;
DROP TABLE IF EXISTS public.site_upvotes CASCADE;
DROP TABLE IF EXISTS public.site_views CASCADE;
DROP TABLE IF EXISTS public.sites CASCADE;
DROP TABLE IF EXISTS public.balances CASCADE;
DROP TABLE IF EXISTS public.profiles CASCADE;
DROP TABLE IF EXISTS public.contact_messages CASCADE;
DROP TABLE IF EXISTS public.forum_posts CASCADE;
DROP TABLE IF EXISTS public.forum_threads CASCADE;
DROP TABLE IF EXISTS public.forum_categories CASCADE;
DROP TABLE IF EXISTS public.notifications CASCADE;

-- ============================================================
-- 1. CORE TABLES
-- ============================================================

-- Profiles (extends auth.users)
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text,
  bio text,
  avatar_url text,
  ad_preferences jsonb DEFAULT '[]'::jsonb,
  mc_username text,
  mc_verified boolean DEFAULT false,
  mc_verify_initiated_at timestamptz,
  is_staff boolean DEFAULT false,
  staff_permissions jsonb DEFAULT '[]'::jsonb,
  xp integer DEFAULT 0,
  discord_id text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Balances
CREATE TABLE public.balances (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  balance numeric DEFAULT 0 NOT NULL,
  updated_at timestamptz DEFAULT now()
);
CREATE INDEX idx_balances_user ON public.balances(user_id);

-- Sites directory
CREATE TABLE public.sites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  url text NOT NULL,
  category text DEFAULT 'Other',
  description text DEFAULT '',
  shortcuts text,
  keywords text[] DEFAULT '{}',
  image_url text,
  owner_user_id uuid REFERENCES auth.users(id),
  user_id uuid REFERENCES auth.users(id),
  owner_name text DEFAULT 'Unknown',
  is_verified boolean DEFAULT false,
  is_active boolean DEFAULT true,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  view_count integer DEFAULT 0,
  click_count integer DEFAULT 0,
  ad_tier text,
  ad_price numeric,
  ad_expires_at timestamptz,
  verification_paid_at timestamptz,
  plot_number text,
  discord_invite text,
  shortcut text,
  submitted_by uuid REFERENCES auth.users(id),
  reviewed_at timestamptz,
  reviewed_by uuid REFERENCES auth.users(id),
  discord_id text,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX idx_sites_slug ON public.sites(slug);
CREATE INDEX idx_sites_status ON public.sites(status);
CREATE INDEX idx_sites_category ON public.sites(category);
CREATE INDEX idx_sites_owner ON public.sites(owner_user_id);
CREATE INDEX idx_sites_ad ON public.sites(ad_tier, ad_expires_at, is_verified);
CREATE INDEX idx_sites_user ON public.sites(user_id);

-- Site views
CREATE TABLE public.site_views (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  site_id uuid REFERENCES public.sites(id) ON DELETE CASCADE,
  viewer_id uuid REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now()
);
CREATE INDEX idx_site_views_dedup ON public.site_views(site_id, viewer_id, created_at);
CREATE INDEX idx_site_views_site ON public.site_views(site_id);

-- Site upvotes
CREATE TABLE public.site_upvotes (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  site_id uuid NOT NULL REFERENCES public.sites(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, site_id)
);
CREATE INDEX idx_site_upvotes_site ON public.site_upvotes(site_id);

-- Site reviews
CREATE TABLE public.site_reviews (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  site_id uuid NOT NULL REFERENCES public.sites(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  rating integer DEFAULT 5 CHECK (rating >= 1 AND rating <= 5),
  comment text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, site_id)
);
CREATE INDEX idx_site_reviews_site ON public.site_reviews(site_id);

-- Site comments
CREATE TABLE public.site_comments (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  site_id uuid NOT NULL REFERENCES public.sites(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  comment text NOT NULL,
  created_at timestamptz DEFAULT now()
);
CREATE INDEX idx_site_comments_site ON public.site_comments(site_id);

-- Site followers
CREATE TABLE public.site_followers (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  site_id uuid NOT NULL REFERENCES public.sites(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, site_id)
);
CREATE INDEX idx_site_followers_site ON public.site_followers(site_id);

-- Bookmarks
CREATE TABLE public.bookmarks (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  site_id uuid NOT NULL REFERENCES public.sites(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, site_id)
);
CREATE INDEX idx_bookmarks_user ON public.bookmarks(user_id, site_id);

-- Transactions
CREATE TABLE public.transactions (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  txn_id text,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  amount numeric NOT NULL,
  type text NOT NULL,
  ref_id text,
  note text,
  created_at timestamptz DEFAULT now()
);
CREATE INDEX idx_transactions_user ON public.transactions(user_id, created_at DESC);
CREATE INDEX idx_transactions_ref ON public.transactions(ref_id);

-- Withdrawal requests
CREATE TABLE public.withdrawal_requests (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  amount numeric NOT NULL,
  mc_username text,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  balance_before numeric,
  balance_after numeric,
  approved_at timestamptz,
  created_at timestamptz DEFAULT now()
);
CREATE INDEX idx_withdrawal_status ON public.withdrawal_requests(status);

-- Site reports
CREATE TABLE public.site_reports (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  site_id uuid NOT NULL REFERENCES public.sites(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  reason text NOT NULL,
  status text,
  created_at timestamptz DEFAULT now()
);

-- Site announcements
CREATE TABLE public.site_announcements (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  site_id uuid NOT NULL REFERENCES public.sites(id) ON DELETE CASCADE,
  title text NOT NULL,
  content text NOT NULL,
  created_at timestamptz DEFAULT now()
);
CREATE INDEX idx_site_announcements ON public.site_announcements(site_id);

-- Global site announcements (ticker bar)
CREATE TABLE IF NOT EXISTS public.announcements (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  title text NOT NULL,
  content text NOT NULL,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_announcements_active ON public.announcements(is_active, created_at DESC);

-- News posts (by approved businesses)
CREATE TABLE IF NOT EXISTS public.news (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  content text NOT NULL,
  category text DEFAULT 'General',
  image_url text,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_news_status ON public.news(status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_news_user ON public.news(user_id);

-- Discord bot site watches (DM alerts when a site goes offline/online)
CREATE TABLE IF NOT EXISTS public.discord_watches (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  discord_user_id text NOT NULL,
  site_slug text NOT NULL,
  last_active boolean,
  created_at timestamptz DEFAULT now(),
  UNIQUE(discord_user_id, site_slug)
);
CREATE INDEX IF NOT EXISTS idx_discord_watches_slug ON public.discord_watches(site_slug);

-- New site columns
ALTER TABLE public.sites ADD COLUMN IF NOT EXISTS business_hours jsonb DEFAULT '{}'::jsonb;
ALTER TABLE public.sites ADD COLUMN IF NOT EXISTS gallery_images text[] DEFAULT '{}';
ALTER TABLE public.sites ADD COLUMN IF NOT EXISTS banner_image_url text;
ALTER TABLE public.sites ADD COLUMN IF NOT EXISTS accent_color text DEFAULT '#3b82f6';
ALTER TABLE public.sites ADD COLUMN IF NOT EXISTS video_url text;
ALTER TABLE public.sites ADD COLUMN IF NOT EXISTS catalog jsonb DEFAULT '[]'::jsonb;
ALTER TABLE public.sites ADD COLUMN IF NOT EXISTS spotlight boolean DEFAULT false;
ALTER TABLE public.sites ADD COLUMN IF NOT EXISTS spotlight_until timestamptz;

-- Profile extras
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS trust_score integer DEFAULT 0;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS accent_color text DEFAULT '#3b82f6';

-- Comment reactions (site comments)
CREATE TABLE IF NOT EXISTS public.comment_reactions (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  comment_id bigint NOT NULL REFERENCES public.site_comments(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  reaction text NOT NULL CHECK (reaction IN ('like', 'happy', 'heart', 'laugh')),
  created_at timestamptz DEFAULT now(),
  UNIQUE(comment_id, user_id)
);

-- Site Q&A
CREATE TABLE IF NOT EXISTS public.site_questions (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  site_id uuid NOT NULL REFERENCES public.sites(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  question text NOT NULL,
  answer text,
  answered_by uuid REFERENCES auth.users(id),
  answered_at timestamptz,
  created_at timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_site_questions_site ON public.site_questions(site_id);

-- User inbox
CREATE TABLE IF NOT EXISTS public.messages (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  sender_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  receiver_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  content text NOT NULL,
  read boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_messages_receiver ON public.messages(receiver_id, read, created_at DESC);

-- Read-only API keys (for third-party apps)
CREATE TABLE IF NOT EXISTS public.api_keys (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  key_hash text UNIQUE NOT NULL,
  name text NOT NULL,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  last_used_at timestamptz
);

-- Maintenance mode (singleton row)
CREATE TABLE IF NOT EXISTS public.site_settings (
  key text PRIMARY KEY,
  value jsonb
);

-- User-created guides hub
CREATE TABLE IF NOT EXISTS public.guides (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  content text NOT NULL DEFAULT '',
  category text DEFAULT 'General',
  status text DEFAULT 'approved' CHECK (status IN ('pending', 'approved', 'rejected')),
  view_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_guides_status ON public.guides(status);
CREATE INDEX IF NOT EXISTS idx_guides_user ON public.guides(user_id);

-- Ad requests
CREATE TABLE public.ad_requests (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  site_id uuid REFERENCES public.sites(id),
  site_name text,
  tier text NOT NULL,
  price numeric NOT NULL,
  image_url text,
  description text,
  duration_days integer DEFAULT 7,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  created_at timestamptz DEFAULT now()
);
CREATE INDEX idx_ad_requests_status ON public.ad_requests(status);

-- Freelance gigs (Fiverr-style marketplace)
CREATE TABLE public.gigs (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text NOT NULL DEFAULT '',
  category text NOT NULL DEFAULT 'Other',
  price numeric NOT NULL DEFAULT 0,
  price_type text DEFAULT 'fixed' CHECK (price_type IN ('fixed', 'hourly', 'negotiable')),
  delivery_days integer DEFAULT 7,
  discord_username text,
  status text DEFAULT 'active' CHECK (status IN ('active', 'paused', 'archived')),
  employment_type text DEFAULT 'gig' CHECK (employment_type IN ('gig', 'job')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
CREATE INDEX idx_gigs_category ON public.gigs(category);
CREATE INDEX idx_gigs_price ON public.gigs(price);
CREATE INDEX idx_gigs_status ON public.gigs(status);
CREATE INDEX idx_gigs_user ON public.gigs(user_id);

-- Review votes
CREATE TABLE public.review_votes (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  review_id bigint NOT NULL REFERENCES public.site_reviews(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  vote_type text NOT NULL CHECK (vote_type IN ('up', 'down')),
  created_at timestamptz DEFAULT now(),
  UNIQUE(review_id, user_id)
);

-- Ads
CREATE TABLE public.ads (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  title text,
  description text,
  image_url text,
  link_url text,
  tier text,
  is_active boolean DEFAULT true,
  click_count integer DEFAULT 0,
  duration_days integer DEFAULT 7,
  created_at timestamptz DEFAULT now()
);

-- Site verification requests
CREATE TABLE public.site_verification_requests (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  site_id uuid REFERENCES public.sites(id),
  site_name text,
  site_url text,
  description text,
  category text,
  status text DEFAULT 'pending',
  created_at timestamptz DEFAULT now()
);
CREATE INDEX idx_site_verification_status ON public.site_verification_requests(status);

-- Wiki pages
CREATE TABLE public.wiki_pages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  url text,
  content text,
  category text DEFAULT 'General',
  slug text UNIQUE,
  source text DEFAULT 'wiki',
  created_at timestamptz DEFAULT now()
);

-- Wiki comments
CREATE TABLE public.wiki_comments (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  wiki_page_id uuid REFERENCES public.wiki_pages(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  content text NOT NULL,
  created_at timestamptz DEFAULT now()
);
CREATE INDEX idx_wiki_comments_page ON public.wiki_comments(wiki_page_id);

-- Departments
CREATE TABLE public.departments (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  description text,
  is_active boolean DEFAULT true,
  display_order integer DEFAULT 0,
  forum_url text,
  forum_category_id integer,
  created_at timestamptz DEFAULT now()
);

-- Collections
CREATE TABLE public.collections (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  is_public boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);
CREATE INDEX idx_collections_user ON public.collections(user_id);

-- Search history
CREATE TABLE public.search_history (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  query text NOT NULL,
  created_at timestamptz DEFAULT now()
);
CREATE INDEX idx_search_history_user ON public.search_history(user_id, created_at DESC);

-- Search analytics
CREATE TABLE public.search_analytics (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  query text NOT NULL,
  user_id uuid,
  results_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);
CREATE INDEX idx_search_analytics_created ON public.search_analytics(created_at);

-- Achievements
CREATE TABLE public.user_achievements (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  achievement_id text NOT NULL,
  achievement_key text,
  unlocked_at timestamptz DEFAULT now(),
  UNIQUE(user_id, achievement_id)
);
CREATE INDEX idx_user_achievements_user ON public.user_achievements(user_id);

-- Daily challenges
CREATE TABLE public.daily_challenges (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  date date UNIQUE NOT NULL,
  target_count integer DEFAULT 5,
  description text,
  created_at timestamptz DEFAULT now()
);

-- Challenge progress
CREATE TABLE public.challenge_progress (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  challenge_id bigint NOT NULL REFERENCES public.daily_challenges(id) ON DELETE CASCADE,
  site_id uuid REFERENCES public.sites(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, challenge_id, site_id)
);

-- Business registrations
CREATE TABLE public.business_registrations (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  business_name text NOT NULL,
  owner_discord text,
  category text,
  plot_number text,
  shortcut text,
  discord_invite text,
  website_url text,
  description text,
  status text DEFAULT 'pending',
  created_at timestamptz DEFAULT now()
);

-- Staff logs
CREATE TABLE public.staff_logs (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role_name text,
  action text NOT NULL,
  details text,
  created_at timestamptz DEFAULT now()
);

-- Staff payroll
CREATE TABLE public.staff_payroll (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  week_start date NOT NULL,
  week_end date,
  actions_count integer DEFAULT 0,
  base_pay numeric DEFAULT 0,
  bonus_pay numeric DEFAULT 0,
  total_due numeric DEFAULT 0,
  status text DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, week_start)
);

-- Auto-deposit rules
CREATE TABLE public.auto_deposit_rules (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  target_firm_name text NOT NULL,
  target_account_id text,
  percentage numeric DEFAULT 100,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Treasury tokens
CREATE TABLE public.treasury_tokens (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  account_id text,
  created_at timestamptz DEFAULT now()
);

-- Forum cache (for scraped forum data)
CREATE TABLE public.forum_cache (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  type text NOT NULL,
  parent_id integer,
  title text,
  last_updated timestamptz DEFAULT now()
);

-- Listings (newer search system)
CREATE TABLE public.listings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  description text,
  category text,
  target_url text,
  icon_url text,
  owner_name text,
  search_aliases text[] DEFAULT '{}',
  is_sponsored boolean DEFAULT false,
  is_verified boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- ============================================================
-- 2. NOTIFICATIONS & FORUMS (from add-features.sql)
-- ============================================================

CREATE TABLE public.notifications (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  type text NOT NULL,
  title text NOT NULL,
  body text,
  link text,
  is_read boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);
CREATE INDEX idx_notifications_user ON public.notifications(user_id, created_at DESC);

CREATE TABLE public.forum_categories (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name text NOT NULL,
  description text,
  slug text UNIQUE NOT NULL,
  sort_order int DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE public.forum_threads (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  category_id bigint NOT NULL REFERENCES public.forum_categories(id) ON DELETE CASCADE,
  title text NOT NULL,
  author_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  is_pinned boolean DEFAULT false,
  is_locked boolean DEFAULT false,
  view_count int DEFAULT 0,
  reply_count int DEFAULT 0,
  last_post_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);
CREATE INDEX idx_forum_threads_cat ON public.forum_threads(category_id, last_post_at DESC);

CREATE TABLE public.forum_posts (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  thread_id bigint NOT NULL REFERENCES public.forum_threads(id) ON DELETE CASCADE,
  author_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  content text NOT NULL,
  is_solution boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);
CREATE INDEX idx_forum_posts_thread ON public.forum_posts(thread_id, created_at);

-- Contact messages
CREATE TABLE public.contact_messages (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id),
  name text NOT NULL,
  subject text NOT NULL,
  message text NOT NULL,
  is_read boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- ============================================================
-- 3. AUTO-PROFILE TRIGGER
-- ============================================================

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
DECLARE
  fallback_name text;
  v_discord_id text;
  meta jsonb;
BEGIN
  meta := COALESCE(NEW.raw_user_meta_data, NEW.raw_app_meta_data, '{}'::jsonb);
  fallback_name := COALESCE(
    meta->>'name',
    meta->>'full_name',
    meta->>'preferred_username',
    meta->>'login',
    split_part(COALESCE(NEW.email, NEW.id::text), '@', 1)
  );
  v_discord_id := COALESCE(
    meta->>'provider_id',
    meta->>'sub'
  );
  BEGIN
    INSERT INTO public.profiles (id, username, avatar_url, discord_id)
    VALUES (
      NEW.id,
      fallback_name,
      COALESCE(meta->>'avatar_url', meta->>'avatar'),
      v_discord_id
    )
    ON CONFLICT (id) DO UPDATE SET
      username = COALESCE(EXCLUDED.username, profiles.username),
      avatar_url = COALESCE(EXCLUDED.avatar_url, profiles.avatar_url),
      discord_id = COALESCE(EXCLUDED.discord_id, profiles.discord_id);
  EXCEPTION WHEN OTHERS THEN
    RAISE WARNING 'handle_new_user: profile insert failed for %: %', NEW.id, SQLERRM;
  END;
  IF v_discord_id IS NOT NULL THEN
    BEGIN
      UPDATE public.sites
      SET owner_user_id = NEW.id, user_id = NEW.id, submitted_by = COALESCE(submitted_by, NEW.id)
      WHERE discord_id = v_discord_id AND owner_user_id IS NULL;
    EXCEPTION WHEN OTHERS THEN
      RAISE WARNING 'handle_new_user: site update failed for %: %', NEW.id, SQLERRM;
    END;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Backfill existing users
INSERT INTO public.profiles (id, username, avatar_url)
SELECT
  id,
  COALESCE(raw_user_meta_data->>'name', raw_user_meta_data->>'full_name', split_part(email, '@', 1)),
  COALESCE(raw_user_meta_data->>'avatar_url', raw_user_meta_data->>'avatar')
FROM auth.users
WHERE id NOT IN (SELECT id FROM public.profiles)
ON CONFLICT (id) DO NOTHING;



-- ============================================================
-- 4. RPC FUNCTIONS
-- ============================================================

DROP FUNCTION IF EXISTS public.increment_balance(uuid, numeric, uuid, numeric);
DROP FUNCTION IF EXISTS public.increment_balance(uuid, numeric);
CREATE OR REPLACE FUNCTION public.increment_balance(target_user_id uuid DEFAULT NULL, deposit_amount numeric DEFAULT NULL)
RETURNS void AS $$
DECLARE
  uid uuid;
  amt numeric;
BEGIN
  uid := target_user_id;
  amt := deposit_amount;
  IF uid IS NULL OR amt IS NULL THEN RAISE EXCEPTION 'Missing user_id or amount'; END IF;
  INSERT INTO public.balances (user_id, balance)
  VALUES (uid, amt)
  ON CONFLICT (user_id)
  DO UPDATE SET balance = balances.balance + amt;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP FUNCTION IF EXISTS public.grant_temp_admin(uuid, integer);
CREATE OR REPLACE FUNCTION public.grant_temp_admin(target_user_id uuid, duration_hours integer DEFAULT 24)
RETURNS void AS $$
BEGIN
  UPDATE public.profiles SET is_staff = true WHERE id = target_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP FUNCTION IF EXISTS public.link_mc_account(uuid, text, boolean);
DROP FUNCTION IF EXISTS public.link_mc_account(uuid, text, boolean, text);
DROP FUNCTION IF EXISTS public.link_mc_account(uuid, text, boolean, timestamptz);
CREATE OR REPLACE FUNCTION public.link_mc_account(target_user_id uuid, mc_username text, verified boolean DEFAULT false, initiated_at timestamptz DEFAULT NULL)
RETURNS void AS $$
BEGIN
  INSERT INTO public.profiles (id, mc_username, mc_verified, mc_verify_initiated_at)
  VALUES (target_user_id, mc_username, verified, initiated_at)
  ON CONFLICT (id)
  DO UPDATE SET mc_username = EXCLUDED.mc_username, mc_verified = EXCLUDED.mc_verified, mc_verify_initiated_at = COALESCE(EXCLUDED.mc_verify_initiated_at, profiles.mc_verify_initiated_at);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.admin_approve_site(p_site_id uuid)
RETURNS void AS $$
BEGIN
  UPDATE public.sites SET status = 'approved', is_verified = true, is_active = true, reviewed_at = NOW() WHERE id = p_site_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.admin_reject_site(p_site_id uuid)
RETURNS void AS $$
BEGIN
  UPDATE public.sites SET status = 'rejected', reviewed_at = NOW() WHERE id = p_site_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP FUNCTION IF EXISTS public.increment_view_count(uuid);
CREATE OR REPLACE FUNCTION public.increment_view_count(p_site_id uuid)
RETURNS void AS $$
BEGIN
  UPDATE public.sites SET view_count = view_count + 1 WHERE id = p_site_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP FUNCTION IF EXISTS public.increment_click_count(uuid);
CREATE OR REPLACE FUNCTION public.increment_click_count(p_site_id uuid)
RETURNS void AS $$
BEGIN
  UPDATE public.sites SET click_count = click_count + 1 WHERE id = p_site_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP FUNCTION IF EXISTS public.increment_review_vote(bigint, text);
CREATE OR REPLACE FUNCTION public.increment_review_vote(row_id bigint, col text)
RETURNS void AS $$
BEGIN
  EXECUTE format('UPDATE public.site_reviews SET %I = %I + 1 WHERE id = $1', col, col) USING row_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP FUNCTION IF EXISTS public.decrement_review_vote(bigint, text);
CREATE OR REPLACE FUNCTION public.decrement_review_vote(row_id bigint, col text)
RETURNS void AS $$
BEGIN
  EXECUTE format('UPDATE public.site_reviews SET %I = GREATEST(%I - 1, 0) WHERE id = $1', col, col) USING row_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- One-time migration for existing DB: add click_count to ads table
-- ALTER TABLE public.ads ADD COLUMN click_count integer DEFAULT 0;

-- One-time backfill: sync sites.view_count with actual site_views count
-- UPDATE public.sites SET view_count = (SELECT count(*) FROM public.site_views WHERE site_id = sites.id);

-- ============================================================
-- 5. SEED DATA
-- ============================================================

INSERT INTO public.forum_categories (name, description, slug, sort_order) VALUES
  ('General Discussion', 'Chat about anything related to DemocracyCraft', 'general', 1),
  ('Site Reviews', 'Share and request reviews of sites', 'site-reviews', 2),
  ('Support', 'Get help with the directory platform', 'support', 3),
  ('Suggestions', 'Ideas for improving the directory', 'suggestions', 4),
  ('Showcase', 'Show off your site listing', 'showcase', 5)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO public.departments (name, slug, description, display_order) VALUES
  ('Department of State', 'state', 'Facilitates elections, executes audits and reports, and ensures cabinet transparency.', 1),
  ('Department of Justice', 'justice', 'Defends the national legal interest and investigates/prosecutes crimes.', 2),
  ('Department of Commerce', 'commerce', 'Supports and oversees the economy of Redmont, providing support to businesses.', 3),
  ('Department of Construction and Transport', 'dct', 'Enforces building regulations and develops Redmont''s infrastructure.', 4),
  ('Department of Education', 'education', 'Oversees the University, DemocracyCraft Wiki, and trades/professions.', 5),
  ('Department of Health', 'health', 'Maintains the health of the people of Redmont and oversees medical facilities.', 6),
  ('Department of Homeland Security', 'homeland-security', 'Enforces Redmont''s laws, maintains criminal records, and manages border control.', 7),
  ('Department of the Interior', 'interior', 'Preserves wildlife and urban areas and manages intergovernmental affairs.', 8),
  ('Department of Public Affairs', 'public-affairs', 'Organizes and hosts server community events and contests.', 9)
ON CONFLICT (slug) DO NOTHING;

-- ============================================================
-- 6. ROW LEVEL SECURITY (from fix-rls.sql)
-- ============================================================

-- Wiki pages RLS
ALTER TABLE public.wiki_pages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow authenticated insert wiki_pages" ON public.wiki_pages
  FOR INSERT TO authenticated
  WITH CHECK (true);

CREATE POLICY "Allow anon select wiki_pages" ON public.wiki_pages
  FOR SELECT TO anon, authenticated
  USING (true);

-- Sites RLS — anon can read approved, authenticated can read all
ALTER TABLE public.sites ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read all sites" ON public.sites
  FOR SELECT TO anon, authenticated
  USING (true);

CREATE POLICY "Users can insert their own sites" ON public.sites
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Owners can update their sites" ON public.sites
  FOR UPDATE TO authenticated
  USING (auth.uid() = owner_user_id OR auth.uid() = user_id)
  WITH CHECK (auth.uid() = owner_user_id OR auth.uid() = user_id);

CREATE POLICY "Staff can update any site" ON public.sites
  FOR UPDATE TO authenticated
  USING ((SELECT is_staff FROM public.profiles WHERE id = auth.uid()) = true)
  WITH CHECK ((SELECT is_staff FROM public.profiles WHERE id = auth.uid()) = true);

-- Profiles RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read profiles" ON public.profiles
  FOR SELECT USING (true);

CREATE POLICY "Users can insert own profile" ON public.profiles
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON public.profiles
  FOR UPDATE TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Staff can update any profile" ON public.profiles
  FOR UPDATE TO authenticated
  USING ((SELECT is_staff FROM public.profiles WHERE id = auth.uid()) = true)
  WITH CHECK ((SELECT is_staff FROM public.profiles WHERE id = auth.uid()) = true);

-- Balances RLS
ALTER TABLE public.balances ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own balance" ON public.balances
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Service role manages balances" ON public.balances
  FOR ALL TO service_role
  USING (true);

-- Departments RLS
ALTER TABLE public.departments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read departments" ON public.departments
  FOR SELECT TO anon, authenticated
  USING (true);

CREATE POLICY "Service role manages departments" ON public.departments
  FOR ALL TO service_role
  USING (true);

-- Staff actions (payout tracking)
CREATE TABLE public.staff_actions (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  staff_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  action_type text NOT NULL CHECK (action_type IN ('ad_commission', 'free_site', 'site_verify')),
  reference_id text,
  description text,
  amount numeric NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE public.staff_actions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Staff can read staff_actions" ON public.staff_actions
  FOR SELECT TO authenticated
  USING ((SELECT is_staff FROM public.profiles WHERE id = auth.uid()) = true);

CREATE POLICY "Staff can insert staff_actions" ON public.staff_actions
  FOR INSERT TO authenticated
  WITH CHECK ((SELECT is_staff FROM public.profiles WHERE id = auth.uid()) = true);

-- Site views RLS
ALTER TABLE public.site_views ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Service role manages views" ON public.site_views
  FOR ALL TO service_role
  USING (true);

-- ============================================================
-- MIGRATIONS (run incrementally on existing DB)
-- ============================================================
-- 2026-07-14: Add mc_verify_initiated_at for payment recency check
-- ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS mc_verify_initiated_at timestamptz;
-- ALTER TABLE public.profiles DROP COLUMN IF EXISTS mc_txn_id;
-- DROP FUNCTION IF EXISTS public.link_mc_account(uuid, text, boolean, text);
-- CREATE OR REPLACE FUNCTION public.link_mc_account... (see above)

-- ============================================================
-- Storage (avatars, site-images buckets) RLS
-- ============================================================

DO $$
BEGIN
  -- Create buckets if they don't exist
  INSERT INTO storage.buckets (id, name, public) VALUES ('avatars', 'avatars', true)
  ON CONFLICT (id) DO UPDATE SET public = true;
  INSERT INTO storage.buckets (id, name, public) VALUES ('site-images', 'site-images', true)
  ON CONFLICT (id) DO UPDATE SET public = true;
  INSERT INTO storage.buckets (id, name, public) VALUES ('ad-images', 'ad-images', true)
  ON CONFLICT (id) DO UPDATE SET public = true;
END $$;

-- Avatar: anyone can view
CREATE POLICY "Anyone can view avatars"
ON storage.objects FOR SELECT TO public
USING (bucket_id = 'avatars');

-- Avatar: authenticated users can upload (restricted to their own user folder)
CREATE POLICY "Users can upload own avatar"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'avatars' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- Avatar: users can update/delete own files
CREATE POLICY "Users can update own avatar"
ON storage.objects FOR UPDATE TO authenticated
USING (
  bucket_id = 'avatars' AND
  (storage.foldername(name))[1] = auth.uid()::text
)
WITH CHECK (
  bucket_id = 'avatars' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "Users can delete own avatar"
ON storage.objects FOR DELETE TO authenticated
USING (
  bucket_id = 'avatars' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- Site images: anyone can view
CREATE POLICY "Anyone can view site images"
ON storage.objects FOR SELECT TO public
USING (bucket_id = 'site-images');

-- Site images: any authenticated user can upload
CREATE POLICY "Users can upload site images"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'site-images');

-- Site images: any authenticated user can update/delete
CREATE POLICY "Users can update site images"
ON storage.objects FOR UPDATE TO authenticated
USING (bucket_id = 'site-images')
WITH CHECK (bucket_id = 'site-images');

CREATE POLICY "Users can delete site images"
ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'site-images');

-- Ad images
CREATE POLICY "Anyone can view ad images"
ON storage.objects FOR SELECT TO public
USING (bucket_id = 'ad-images');

CREATE POLICY "Users can upload ad images"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'ad-images');

CREATE POLICY "Users can update ad images"
ON storage.objects FOR UPDATE TO authenticated
USING (bucket_id = 'ad-images')
WITH CHECK (bucket_id = 'ad-images');

CREATE POLICY "Users can delete ad images"
ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'ad-images');

-- ============================================================
-- DONE!
-- ============================================================
