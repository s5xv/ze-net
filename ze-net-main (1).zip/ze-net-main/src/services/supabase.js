import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;

// Anon key ONLY. This bundle is public — every visitor can read it — so a
// service-role key here would hand anyone full read/write/delete on the whole
// database with RLS bypassed. (There used to be a
// `|| import.meta.env.VITE_SUPABASE_SERVICE_ROLE_KEY` fallback on this line.)
// The service-role key belongs to the serverless functions in /api only.
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  console.error(
    'Missing VITE_SUPABASE_URL or VITE_SUPABASE_ANON_KEY. ' +
    'Set both in Vercel → Project → Settings → Environment Variables, then redeploy.'
  );
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    // MUST be pinned. supabase-js defaults flowType to 'implicit', but the
    // Discord callback comes back as ?code=... (the PKCE code flow). In
    // implicit mode the client never stores a code_verifier, so on load it
    // decides the URL is "not a callback", ignores the ?code= entirely, and
    // reports the user as signed out — which is what was bouncing everyone
    // straight back to /login. Setting 'pkce' makes signInWithOAuth send a
    // code_challenge and store the verifier, so detectSessionInUrl picks the
    // code up and exchanges it automatically.
    flowType: 'pkce',
    detectSessionInUrl: true,
    persistSession: true,
    autoRefreshToken: true,
  },
});
