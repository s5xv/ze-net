import { useState, useEffect } from 'react';
import { supabase } from '../services/supabase';

// One shared auth state for the whole app.
//
// This used to create a fresh subscription (and a fresh `loading: true`)
// every time any component called useAuth(). That meant a page mounting
// *after* auth had already resolved briefly saw `user: null`, and guards
// like Account's `if (!user) navigate('/login')` fired on that flash. The
// old 2-second timeout fallback made it worse: on a slow code exchange it
// would call getSession() before the exchange finished and hard-set the
// user to null.
//
// Now there's a single module-level subscription and a single snapshot, so
// every consumer reads the same already-resolved value on mount.

let snapshot = { user: null, loading: true };
const listeners = new Set();

function publish(user, loading) {
  snapshot = { user, loading };
  listeners.forEach((fn) => fn(snapshot));
}

supabase.auth.onAuthStateChange((_event, session) => {
  publish(session?.user ?? null, false);
});

// Backstop in case INITIAL_SESSION never lands. getSession() resolves only
// after the client has finished processing any OAuth callback in the URL,
// so unlike a blind timeout it can never report "signed out" while the code
// exchange is still in flight.
supabase.auth
  .getSession()
  .then(({ data }) => {
    if (snapshot.loading) publish(data?.session?.user ?? null, false);
  })
  .catch(() => {
    if (snapshot.loading) publish(null, false);
  });

export function useAuth() {
  const [state, setState] = useState(snapshot);

  useEffect(() => {
    listeners.add(setState);
    // Catch anything that resolved between render and effect.
    setState(snapshot);
    return () => {
      listeners.delete(setState);
    };
  }, []);

  return state;
}
