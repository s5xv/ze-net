import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../services/supabase';
import Layout from '../components/Layout';
import { useAuth } from '../hooks/useAuth';

export default function Login() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  // If auth already resolved and we have a session, don't strand the user on
  // a sign-in form they've already completed.
  useEffect(() => {
    if (!loading && user) navigate('/account', { replace: true });
  }, [user, loading, navigate]);

  // Supabase appends ?error=...&error_description=... when Discord or the
  // callback itself rejects. Surface it instead of showing a blank form.
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const desc = params.get('error_description') || params.get('error');
    if (desc) setError(desc.replace(/\+/g, ' '));
  }, []);

  const handleLogin = async () => {
    setError('');
    setBusy(true);
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'discord',
        options: { redirectTo: window.location.origin + '/account' }
      });
      if (error) {
        setError(error.message);
        setBusy(false);
      }
      // On success the browser navigates away to Discord, so leave busy set.
    } catch (e) {
      setError('Login failed: ' + e.message);
      setBusy(false);
    }
  };

  return (
    <Layout user={user}>
      <main className="flex-grow flex items-center justify-center px-4 py-12">
        <div className="max-w-md w-full bg-white dark:bg-[#303134] rounded-2xl p-8 border border-gray-200 dark:border-gray-700 shadow-lg text-center">
          <h1 className="text-3xl font-bold mb-4">Sign In</h1>
          <p className="text-gray-600 dark:text-gray-400 mb-6">Sign in with your Discord account to access all features</p>
          {error && <div className="mb-4 p-3 bg-red-900/30 border border-red-800 rounded-lg text-red-400 text-sm">{error}</div>}
          <button onClick={handleLogin} disabled={busy} className="w-full px-6 py-3 bg-[#5865F2] hover:bg-[#4752C4] disabled:opacity-60 disabled:cursor-not-allowed text-white font-semibold rounded-lg transition-colors flex items-center justify-center gap-2">
            <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03z"/></svg>
            {busy ? 'Redirecting to Discord\u2026' : 'Sign in with Discord'}
          </button>
        </div>
      </main>
    </Layout>
  );
}
